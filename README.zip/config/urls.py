from django.contrib import admin
from django.urls import path
import teamapp.views

from django.views import Test1
#from django.views import BlogList, BlogDetail

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',admin.teamapp.urls),
    path('list/',teamapp.views.list),
    #path('detail',teamapp.views),
    #path('detail', BlogDetail.as_view()),
]

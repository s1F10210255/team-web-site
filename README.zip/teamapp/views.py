#from django.shortcuts import render
#from django.http import HttpResponse
#from django.views.generic import ListView ,DetailView
#from .models import BlogModel

class Test1():
    pass

#class BlogList(ListView):
    #template_name ='list.html'
    #model = BlogModel

#class BlogDetail(DetailView):
    #template_name ='detail.html'
    #model = BlogModel
